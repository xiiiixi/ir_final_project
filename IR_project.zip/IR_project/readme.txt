1.open cmd and input the command below:
	python3 server.py or python server.py
2.The cmd will show which address you're using, for example:
	Running on http://127.0.0.1:5000
3.Input this address into the browser
4.Start to search

Requirements
flask
requests
nltk
whose